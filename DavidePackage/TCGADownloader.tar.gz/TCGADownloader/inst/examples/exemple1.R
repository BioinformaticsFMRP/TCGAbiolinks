#exemple1

\dontrun{ 
  x<-TCGAQuery()
}